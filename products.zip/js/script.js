// Dummy Products Data
const products = [
  {
    id: 1,
    name: "TIMEWEAR",
    price: 1299,
    image: "images/product1.jpg"
  },
  {
    id: 2,
    name: "Carlington",
    price: 2499,
    image: "images/product2.jpg"
  },
  {
    id: 3,
    name: "Michael Kors",
    price: 999,
    image: "images/product3.jpg"
  },
  {
    id: 4,
    name: "Titan",
    price: 499,
    image: "images/product4.jpg"
  }
];

// Load products on products.html
const productsContainer = document.getElementById("products-container");
if (productsContainer) {
  products.forEach(product => {
    productsContainer.innerHTML += `
      <div class="product-card">
        <img src="${product.image}" alt="${product.name}" />
        <h3>${product.name}</h3>
        <p>₹${product.price}</p>
        <label for="qty-${product.id}">Quantity:</label>
        <input type="number" id="qty-${product.id}" min="1" value="1" style="width: 60px; padding: 5px; margin: 5px 0;" />
        <button class="add-btn" onclick="addToCart(${product.id})">Add to Cart</button>
      </div>
    `;
  });
}

// Cart logic (localStorage)
function addToCart(id) {
  const qtyInput = document.getElementById(`qty-${id}`);
  const quantity = parseInt(qtyInput.value);
  if (quantity < 1 || isNaN(quantity)) {
    alert("Please enter a valid quantity.");
    return;
  }

  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  let product = products.find(p => p.id === id);

  for (let i = 0; i < quantity; i++) {
    cart.push(product);
  }

  localStorage.setItem("cart", JSON.stringify(cart));
  alert(`${quantity} x ${product.name} added to cart!`);
}

// Load Cart on cart.html
const cartItemsContainer = document.getElementById("cart-items");

if (cartItemsContainer) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];

  function updateCartDisplay() {
    cartItemsContainer.innerHTML = "";
    let total = 0;

    cart.forEach((item, index) => {
      cartItemsContainer.innerHTML += `
        <div class="cart-card">
          <img src="${item.image}" alt="${item.name}" />
          <div class="cart-info">
            <h3>${item.name}</h3>
            <p>₹${item.price}</p>
          </div>
          <button class="remove-btn" onclick="removeItem(${index})">Remove</button>
        </div>
      `;
      total += item.price;
    });

    const cartTotal = document.getElementById("cart-total");
    cartTotal.innerHTML = `Total: ₹${total}`;
  }

  window.removeItem = function(index) {
    cart.splice(index, 1);
    localStorage.setItem("cart", JSON.stringify(cart));
    updateCartDisplay();
  }

  updateCartDisplay();
}

// EmailJS Contact Form
(function() {
  emailjs.init("vfmcsmxk2FZT1nVBf"); // Your Public Key
})();

const contactForm = document.getElementById("contact-form");
if (contactForm) {
  contactForm.addEventListener("submit", function (e) {
    e.preventDefault();

    emailjs.sendForm('service_sshxtzd', 'template_yvl6ulk', this)
      .then(function () {
        document.getElementById("form-message").textContent = "Message sent successfully!";
        contactForm.reset();
      }, function (error) {
        document.getElementById("form-message").textContent = "Something went wrong!";
        console.log(error);
      });
  });
}
// Navbar Hamburger Toggle
document.addEventListener("DOMContentLoaded", () => {
  const toggleBtn = document.getElementById("menu-toggle");
  const navLinks = document.getElementById("nav-links");

  toggleBtn.addEventListener("click", () => {
    navLinks.classList.toggle("show");
  });
});

